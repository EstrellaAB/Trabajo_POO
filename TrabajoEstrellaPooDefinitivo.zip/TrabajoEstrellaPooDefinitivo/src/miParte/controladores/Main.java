package miParte.controladores;

import miParte.servicios.Menu;

public class Main {

	public static void main(String[] args) {
		new Menu().menu();

	}

}
