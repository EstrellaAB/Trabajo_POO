package miParte.objetos;

public class UsuarioAdmind extends Usuarios {

	protected String nombreAdmin = "Guillamon";
	protected String passAdmin = "Guillamon1234";
	
	public UsuarioAdmind() {
		super();
		
	}


	
}
