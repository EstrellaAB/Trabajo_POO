package com.proyecto.principal.repositorios;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.proyecto.principal.entidades.PagoImpl;

public class PagoRepositorio {

	public int insertarPago(PagoImpl pago) {
		
		int resultado = 0;

		try {
			ConexionBBDD conexionBBDD = new ConexionBBDD();
			Connection conexion = conexionBBDD.conectar();

			String sql = "INSERT INTO Pagos(titularTarjeta, numTarjeta, mesCaducidad, anyoCaducidad) VALUES(?, ?, ?, ?)";
			PreparedStatement ps = conexion.prepareStatement(sql);
			ps.setString(1, pago.getTitularTarjeta());
			ps.setInt(2, pago.getNumTarjeta());
			ps.setDate(3, pago.getMesCaducidad());
			ps.setDate(4, pago.getAnyoCaducidad());
			
			ps.executeUpdate();
			ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                resultado = rs.getInt(1);
            }
			rs.close();
			ps.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resultado;
	}
}
