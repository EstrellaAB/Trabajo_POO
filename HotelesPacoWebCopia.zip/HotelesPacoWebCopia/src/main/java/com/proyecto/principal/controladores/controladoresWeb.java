package com.proyecto.principal.controladores;

import java.sql.Date;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.proyecto.principal.entidades.PagoImpl;
import com.proyecto.principal.entidades.ReservaImpl;
import com.proyecto.principal.servicios.HotelServicio;
import com.proyecto.principal.servicios.PagoServicio;
import com.proyecto.principal.servicios.ReservaServicio;

@Controller
public class controladoresWeb {

	@GetMapping("index")
	public ModelAndView landPage() {
		
		ModelAndView maw = new ModelAndView("index");
		
		return maw;
		}
	
	@GetMapping("inicioSesion")
	public ModelAndView inicioSesion() {
		
		ModelAndView maw = new ModelAndView("inicioSesion");
		
		return maw;
	}
	
	@GetMapping("Login")
	public ModelAndView LogIn(String correo, String nombreUsuario, String contrasena) {
		
		ModelAndView maw = new ModelAndView("Login");
		
		return maw;
	}

	
	@GetMapping("reservaHote")
	public ModelAndView reservaHotel() {
		
		ModelAndView maw = new ModelAndView("reservaHote");
		
		return maw;
	}

	@GetMapping("informacion")
	public ModelAndView informacion() {
		
		ModelAndView maw = new ModelAndView("informacion");
		
		return maw;
	}
	
	@GetMapping("/hoteles")
	public ModelAndView obtenerHoteles() {
		
		ModelAndView maw = new ModelAndView("hoteles");
		
		// Llamar al servicio
		HotelServicio hs = new HotelServicio();
		maw.addObject("listaHoteles", hs.obtenerTodosLosHoteles());
		
		return maw;		
	}
	
	@GetMapping("habitaciones")
	public ModelAndView habitaciones(@RequestParam("hotelId") int idHotel) {
		
		ModelAndView maw = new ModelAndView("habitaciones");
		HotelServicio hs = new HotelServicio();
		maw.addObject("listaHabitaciones", hs.otenerHabitacionesHotelSeleccionado(idHotel));
		
		return maw;
	}

	@GetMapping("habIndividual")
	public ModelAndView habIndividual() {
		
		ModelAndView maw = new ModelAndView("habIndividual");
		
		return maw;
	}
	@GetMapping("habDoble")
	public ModelAndView habDoble() {
		
		ModelAndView maw = new ModelAndView("habDoble");
		
		return maw;
	}
	@GetMapping("habSuite")
	public ModelAndView habSuite() {
		
		ModelAndView maw = new ModelAndView("habSuite");
		
		return maw;
	}
	
	@GetMapping("/reserva")
	public ModelAndView nuevaReserva() {
		
		ModelAndView maw = new ModelAndView("reserva");
		
		return maw; 
	}
	
	@PostMapping
    public void crearReserva(@RequestParam("titular") String titular, @RequestParam("numero_tarjeta") String numero_tarjeta, 
    		@RequestParam("mes_caducidad") int mes_caducidad, @RequestParam("anio_caducidad") int anio_caducidad,
    		 @RequestParam("id_Hotel") int id_Hotel, @RequestParam("id_habitacion") int id_habitacion,
    		 @RequestParam("fecha_entrada") Date fecha_entrada, @RequestParam("fecha_salida") Date fecha_salida) {
		
        // Crear el registro de pago
		PagoServicio pagoServicio = new PagoServicio();
		PagoImpl pago = pagoServicio.crearObjetoPago(titular, id_habitacion, fecha_entrada, fecha_salida);
		int idPago = pagoServicio.insertarPago(pago);
		
		
		// Reserva
		ReservaServicio reservaServicio = new ReservaServicio();
		ReservaImpl reserva = reservaServicio.crearObjetoReserva(fecha_entrada, fecha_salida, idPago, id_Hotel, id_habitacion);
		
 		// Llamar al metodo insert de reserva
		reservaServicio.insertarReserva(reserva);
		
        
	}
	
}
	