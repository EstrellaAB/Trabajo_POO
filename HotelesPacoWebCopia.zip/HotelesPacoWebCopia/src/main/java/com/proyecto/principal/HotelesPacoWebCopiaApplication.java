package com.proyecto.principal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelesPacoWebCopiaApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelesPacoWebCopiaApplication.class, args);
	}

}
