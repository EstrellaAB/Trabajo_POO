package com.proyecto.principal.repositorios;

public class ConsultasSQL {

}
