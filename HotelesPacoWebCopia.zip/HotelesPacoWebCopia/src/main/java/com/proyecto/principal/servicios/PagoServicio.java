package com.proyecto.principal.servicios;

import java.sql.Date;

import com.proyecto.principal.entidades.PagoImpl;
import com.proyecto.principal.repositorios.PagoRepositorio;

public class PagoServicio {
	
	public PagoImpl crearObjetoPago (String titularTarjeta, int numTarjeta, Date mesCaducidad, Date anioCaducidad) {
		
		PagoImpl resultado = new PagoImpl(); 
		
		resultado.setTitularTarjeta(titularTarjeta);
		resultado.setNumTarjeta(numTarjeta);
		resultado.setMesCaducidad(mesCaducidad);
		resultado.setAnyoCaducidad(anioCaducidad);
		
		return resultado; 
	}
	
	public int insertarPago(PagoImpl pago) {
		int resultado;
	    PagoRepositorio pagoRepositorio = new PagoRepositorio();
	    resultado = pagoRepositorio.insertarPago(pago);
	    return resultado;
	}

}