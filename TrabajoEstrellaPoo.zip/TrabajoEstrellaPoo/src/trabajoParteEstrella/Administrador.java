package trabajoParteEstrella;

public class Administrador extends Registrar{

	public Object nombreUsuario;
	
	    public Administrador(String nombreUsuario, String contrasena) {
	        super(nombreUsuario, contrasena);
	    
	}

}
