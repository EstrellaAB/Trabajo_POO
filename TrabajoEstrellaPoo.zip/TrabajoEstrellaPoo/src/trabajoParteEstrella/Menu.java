package trabajoParteEstrella;


import java.util.Scanner;

public class Menu extends Usuario {
	
	//constructor
	
	public void menu() {
	    try {
	    	Scanner sc = new Scanner(System.in);
	        boolean repit = true;
	        Usuario registroUsuarios = new Usuario(100); 
	         // Usuario registrado después del registro
	        Administrador admin = new Administrador("admin", "guillamonApruebame");
	
	        while (repit) {
	            // Menu
	            int hacerUsu;
	            System.out.println("Bienvenido a hoteles Paco. ¿Qué quieres hacer?");
	            System.out.println("1. Registrarse.");
	            System.out.println("2. Iniciar sesión.");
	            System.out.println("3. Iniciar sesión administrador.");
	            System.out.println("4. Salir.");
	            hacerUsu = sc.nextInt(); // Lee la opción ingresada por el usuario
	
	            switch (hacerUsu) { // Proceso para saber la opción elegida por el usuario
	                case 1:
	                    new Registrar(nombreUsuario, contraseña).registrar();
	                    break;
	
	                case 2:
	                	if (registroUsuarios.verificarUsuario(nombreUsuario, contraseña)) {
	                        System.out.println("Inicio de sesión exitoso!");
	                    } else {
	                        System.out.println("Nombre de usuario o contraseña incorrectos.");
	                    }
	                    break;
	
	                case 3:
	                	LoginAdmin.loginAdmin(admin); // Ejecuto el proceso de inicio de sesión del administrador
	                    break;
	
	                case 4:
	                    repit = false; // Salgo del bucle while para terminar el programa
	                    System.out.println("Has salido del programa. ¡Adiós!");
	                    break;
	
	                default:
	                    System.out.println("No ingresaste un número válido.");
	            }
	        }
	        sc.close(); // Cierro el Scanner al finalizar el programa
	    } catch (java.util.InputMismatchException a) {
	        System.out.println("No puedes ingresar letras.");
	    }

	}   
}