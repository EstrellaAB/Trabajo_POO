package trabajoParteEstrella;

import java.util.ArrayList;
import java.util.Scanner;

public  class  Usuario {
	public static Scanner sc = new Scanner(System.in); // Instancia de Scanner para entrada estándar

    // Clase para representar usuarios
		
        protected String nombreCompleto;
        protected String nombreUsuario;
        protected String contraseña;
        protected int fechaCumple;
        private String[][] usuarios;
        private int capacidadMaxima;
        private int numUsuarios;

        // Constructor
        public Usuario(int capacidadMaxima) {
            this.capacidadMaxima = capacidadMaxima;
            this.usuarios = new String[capacidadMaxima][2]; // Array para almacenar usuarios (nombre completo y contraseña)
            this.numUsuarios = 0; // Inicialmente no hay usuarios registrados
        }
        
        
		public Usuario(String nombreCompleto, String nombreUsuario, String contraseña, int fechaCumple) {
			this.nombreCompleto = nombreCompleto;
			this.nombreUsuario = nombreUsuario;
			this.contraseña = contraseña;
			this.fechaCumple = fechaCumple;
		}


		public Usuario() {
		}
		
		

		public Usuario(String nombreUsuario, String contraseña) {
			this.nombreUsuario = nombreUsuario;
			this.contraseña = contraseña;
		}
			
		

		public String getNombreCompleto() {
			return nombreCompleto;
		}


		public void setNombreCompleto(String nombreCompleto) {
			this.nombreCompleto = nombreCompleto;
		}


		public String getNombreUsuario() {
			return nombreUsuario;
		}


		public void setNombreUsuario(String nombreUsuario) {
			this.nombreUsuario = nombreUsuario;
		}


		public String getContraseña() {
			return contraseña;
		}


		public void setContraseña(String contraseña) {
			this.contraseña = contraseña;
		}


		public int getFechaCumple() {
			return fechaCumple;
		}


		public void setFechaCumple(int fechaCumple) {
			this.fechaCumple = fechaCumple;
		}


	// Método para verificar la contraseña
       boolean verificarContraseña(String contraseña) {
            return this.contraseña.equals(contraseña);
        }
       
       public void usuarios(Usuario usuarioRegistrado) {
   		ArrayList<Usuario> usuariosRegistrados = new ArrayList<>();
   		
           // Acceder a los usuarios almacenados en el ArrayList
           for (Usuario usuario : usuariosRegistrados) {
               System.out.println("Nombre: " + usuario.getNombreUsuario() );
           }
   	}
       
       // Método para registrar un nuevo usuario
       public void registrarUsuario(String nombreCompleto, String contrasena) {
           if (numUsuarios < capacidadMaxima) {
               usuarios[numUsuarios][0] = nombreCompleto;
               usuarios[numUsuarios][1] = contrasena;
               numUsuarios++;
               System.out.println("Usuario registrado exitosamente.");
           } else {
               System.out.println("No se puede registrar más usuarios. Capacidad máxima alcanzada.");
           }
       }

       // Método para verificar si un usuario y contraseña coinciden
       public boolean verificarUsuario(String nombreUsuario, String contrasena) {
           for (int i = 0; i < numUsuarios; i++) {
               if (usuarios[i][0].equals(nombreUsuario) && usuarios[i][1].equals(contrasena)) {
                   return true;
               }
           }
           return false;
       }
}