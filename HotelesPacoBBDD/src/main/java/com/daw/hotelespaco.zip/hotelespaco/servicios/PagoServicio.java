package com.daw.hotelespaco.servicios;

import com.daw.hotelespaco.entidades.PagoImpl;
import com.daw.hotelespaco.repositorio.PagoRepositorio;

public class PagoServicio {

//	public DatosDePagoImpl crearObjetoPago (String titularTarjeta, int numTarjeta, Date mesCaducidad, Date anyoCaducidad) {
//		DatosDePagoImpl resultado = new DatosDePagoImpl();
//		
//		resultado.setTitularTarjeta(titularTarjeta);
//		resultado.setNumTarjeta(numTarjeta);
//		resultado.setMesCaducidad(mesCaducidad);
//		resultado.setAnyoCaducidad(anyoCaducidad);
//		
//		return resultado; 
//	}
	
	public void insertarReserva(PagoImpl pago) {
		
		// LLAMAR AL REPOSITORIO
		int resultado; 
		PagoRepositorio pagoRepo = new PagoRepositorio(); 
		pagoRepo.insertarPago(pago);
		 
	}
}
