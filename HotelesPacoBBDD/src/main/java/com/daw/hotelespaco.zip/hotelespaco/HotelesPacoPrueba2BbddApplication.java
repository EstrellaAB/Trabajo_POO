package com.daw.hotelespaco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelesPacoPrueba2BbddApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelesPacoPrueba2BbddApplication.class, args);
	}

}
