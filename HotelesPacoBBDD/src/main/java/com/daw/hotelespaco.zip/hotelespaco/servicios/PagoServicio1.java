package com.daw.hotelespaco.servicios;

import java.sql.Date;

import com.daw.hotelespaco.entidades.PagoImpl;

public class PagoServicio1 {
	
	public PagoImpl crearObjetoPago (String titularTarjeta, int numTarjeta, Date mesCaducidad, Date anioCaducidad) {
		
		PagoImpl resultado = new PagoImpl(); 
		
		return resultado; 
	}

}
